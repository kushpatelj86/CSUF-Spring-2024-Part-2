import sqlite3
import database
# Connect to the SQLite database
conn = database.connect_db()

# Write a query to retrieve data

# Execute the query and fetch data
print(conn)


